# 💎 My Workout Journey - Versione Finale

App web **glassmorphism** pulita e professionale con **istruzioni dettagliate** per ogni esercizio.

## ✨ Versione Finale - Focus su Istruzioni

### 🎯 Caratteristiche Principali

#### **Niente Immagini, Solo Contenuto di Qualità**
- ✅ **Istruzioni passo-passo dettagliate** per ogni esercizio
- ✅ **Sezioni espandibili** "Come eseguire" con guida completa
- ✅ **Consigli pratici** per esecuzione corretta
- ✅ **Note speciali** per osteoporosi dove rilevante
- ✅ **Design pulito** senza distrazioni

#### **Esempio di Contenuto**

Ogni esercizio include:
1. **Nome e emoji** identificativa
2. **Serie/ripetizioni** chiare
3. **Descrizione breve** (visibile sempre)
4. **Istruzioni dettagliate** (espandibili) con:
   - Posizione di partenza
   - Movimento passo-passo
   - Cosa concentrarsi
   - Come respirare
5. **Consigli pratici** per evitare errori comuni
6. **Note speciali** quando importante (es. priorità per osteoporosi)

## 🎨 Design Glassmorphism

- **Sfondo gradiente** viola-rosa-blu animato
- **Card trasparenti** effetto vetro sfumato
- **Timer circolare** con anello progressivo
- **Animazioni fluide** su ogni interazione
- **Progress bar + ring** per monitorare i progressi

## 📱 Funzionalità

- ✅ **Checkbox** per spuntare esercizi completati
- ✅ **Espandi/Chiudi** istruzioni dettagliate per ogni esercizio
- ⏱️ **Timer integrato** per plank e riposi
- 💾 **Salvataggio automatico** progressi
- 📊 **Barra progressi** + percentuale circolare
- 🔄 **Reset** per ricominciare una sessione
- 📱 **Ottimizzata mobile** (iPhone/Android)
- 🔌 **Funziona offline** dopo prima visita
- 🏠 **Installabile** come app

## 🏋️‍♀️ Contenuto Completo

### **Mobilità** (7 esercizi)
Istruzioni dettagliate per preparare il corpo

### **Parte Superiore** (12 esercizi)
- Schiena: Rematore, pull-over, superman, reverse fly
- Spalle: Military press, alzate laterali/frontali, scrollate
- Braccia: Curl bicipiti/martello, french press, kickback

### **Parte Inferiore + Core** (12 esercizi)
- Gambe: Squat, affondi, stacchi rumeni, ponte glutei, calf raises
- Core: Plank, side plank, crunch, russian twist, dead bug, mountain climbers

### **Stretching** (6 esercizi)
Allungamenti completi per defaticamento

## 🚀 Installazione

### Deploy su GitHub Pages

1. **Crea o usa repository esistente**
2. **Sostituisci `index.html`** con questo nuovo file
3. **Commit delle modifiche**
4. **Attendi 1-2 minuti** → Aggiornamento automatico!

### File Necessari
- `index.html` (file principale - **QUESTO** è l'importante)
- `manifest.json` (configurazione PWA)
- `sw.js` (service worker offline)
- `icon-192.png` e `icon-512.png` (icone app)
- `README.md` (questa documentazione)

## 💡 Come Usare l'App

### Durante l'Allenamento

1. **Seleziona la sezione** (Mobilità, Superiore, Inferiore, Stretching)
2. **Leggi nome e descrizione breve** dell'esercizio
3. **Tocca "▶ Come eseguire"** per vedere istruzioni dettagliate
4. **Segui i passi** uno per uno
5. **Spunta la checkbox** quando completi l'esercizio
6. **Usa il timer** per plank e riposi tra serie

### Vantaggi delle Istruzioni Espandibili

- ✅ Interfaccia pulita quando non servono
- ✅ Accesso rapido quando ti servono
- ✅ Puoi leggere durante l'esercizio
- ✅ Ideale per imparare la tecnica corretta

## 🎯 Obiettivi

### Focus Osteoporosi
- **Squat**: 4 serie (priorità assoluta!)
- **Affondi**: 3 serie
- **Stacchi rumeni**: 3 serie
- **Military press**: 3 serie

Questi esercizi con carico progressivo sono **fondamentali** per:
- Migliorare densità ossea
- Rafforzare muscoli di supporto
- Prevenire fratture
- Mantenere equilibrio e coordinazione

### Progressione
1. **Settimana 1-2**: Impara la tecnica corretta con peso leggero (4kg)
2. **Settimana 3-4**: Consolida la forma, aumenta leggermente il peso
3. **Settimana 5+**: Progressione graduale quando 12 ripetizioni diventano facili

## 📅 Pianificazione Settimanale

| Giorno | Attività |
|--------|----------|
| **Lunedì** | Mobilità (10 min) + Parte Superiore (30-40 min) |
| **Martedì** | Cardio: Balla e Snella (60 min) |
| **Mercoledì** | Riposo o mobilità leggera (10 min) |
| **Giovedì** | Mobilità (10 min) + Parte Inferiore + Core (40-50 min) |
| **Venerdì** | Cardio: Balla e Snella (60 min) |
| **Sabato** | Riposo attivo: passeggiata, stretching |
| **Domenica** | Riposo completo |

## ⚡ Performance

- **Dimensione totale**: ~45KB (leggerissima!)
- **Nessuna immagine esterna** = caricamento istantaneo
- **Tutto in un file** = semplicità massima
- **Funziona offline** = sempre disponibile

## 🔧 Personalizzazione

### Modificare Timer
Cerca `<Timer duration={60}` e cambia 60 con i secondi desiderati (es. 90 per riposi più lunghi).

### Aggiungere Esercizi
Copia la struttura di un esercizio esistente e modifica:
- `id`: numero progressivo
- `name`: nome esercizio
- `sets`: serie e ripetizioni
- `brief`: descrizione breve
- `instructions`: array di passi dettagliati
- `tips`: consigli pratici
- `note` (opzionale): note importanti

### Cambiare Colori
Cerca le sezioni `color:` e modifica i gradienti Tailwind:
- `from-pink-500 to-rose-500` (Mobilità)
- `from-purple-500 to-indigo-500` (Superiore)
- `from-blue-500 to-cyan-500` (Inferiore)
- `from-emerald-500 to-teal-500` (Stretching)

## ✅ Vantaggi di Questa Versione

| Aspetto | Questa Versione |
|---------|-----------------|
| **Contenuto** | Istruzioni professionali dettagliate |
| **Design** | Pulito, moderno, senza distrazioni |
| **Peso** | 45KB (leggerissima) |
| **Utilità** | Impari la tecnica corretta |
| **Usabilità** | Espandi solo quello che ti serve |
| **Focus** | Completamente sulla qualità dell'esecuzione |

## 💪 Filosofia

> **La forma corretta è più importante del peso sollevato.**

Questa app ti aiuta a:
- ✅ Eseguire ogni esercizio nella forma corretta
- ✅ Evitare infortuni
- ✅ Massimizzare i benefici per osteoporosi
- ✅ Costruire fondamenta solide per progressione futura

---

**Buon allenamento! 💪✨**

Made with 💜 for health and strength
